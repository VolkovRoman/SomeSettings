#!/usr/bin/env bash

BASE_DIR=~/PycharmProjects/finance_
sudo sh -c ''
rm -rf /tmp/home
rm /tmp/migrations_`date +%d%m`.tar
rm /tmp/mf_dev_`date +%d%m`.sql

scp dev@mfdev:/home/dev/dumps_`date +%Y`_`date +%m%d`/mf_dev_`date +%m%d`.sql /tmp/
scp dev@mfdev:/home/dev/dumps_`date +%Y`_`date +%m%d`/mf_dev_queries_`date +%m%d`.sql /tmp/
scp dev@mfdev:/home/dev/dumps_`date +%Y`_`date +%m%d`/migrations_`date +%m%d`.tar /tmp/
scp dev@mfdev:/home/dev/dumps_`date +%Y`_`date +%m%d`/mongodb_`date +%m%d`.tar /tmp/

sudo su -l -c "psql -U postgres -c 'DROP DATABASE finance;'" postgres
sudo su -l -c "psql -U postgres -c 'DROP DATABASE fin_queries;'" postgres
sudo su -l -c "psql -U postgres -c 'CREATE DATABASE finance OWNER finance;'" postgres
sudo su -l -c "psql -U postgres -c 'CREATE DATABASE fin_queries OWNER finance;'" postgres
sudo su -l -c "psql -U postgres -c 'CREATE EXTENSION IF NOT EXISTS plpythonu; CREATE EXTENSION IF NOT EXISTS pg_prewarm; CREATE EXTENSION IF NOT EXISTS pg_trgm;' -d finance" postgres
sudo su -l -c "psql -U postgres -c 'CREATE EXTENSION IF NOT EXISTS plpythonu; CREATE EXTENSION IF NOT EXISTS pg_prewarm; CREATE EXTENSION IF NOT EXISTS pg_trgm;' -d fin_queries" postgres

PGPASSWORD="21452" psql -h localhost finance finance -f /tmp/mf_dev_`date +%m%d`.sql
echo " ------------ Восстановлен бэкап БД mf_dev в БД finance"
PGPASSWORD="21452" psql -h localhost fin_queries finance -f /tmp/mf_dev_queries_`date +%m%d`.sql
echo " ------------ Восстановлен бэкап БД mf_dev_queries в БД fin_queries"

cd $BASE_DIR/finance
for i in apps/*/migrations/; do rm -rf $i; done
for i in apps/insurance/*/migrations/; do rm -rf $i; done
tar xvf /tmp/migrations_`date +%m%d`.tar -C /tmp
cp -r /tmp/home/dev/dumps_`date +%Y`_`date +%m%d`/migrations/apps/ .
echo " ------------ Восстановлены миграции Джанго"

tar xvf /tmp/mongodb_`date +%m%d`.tar -C /tmp
mongorestore --nsInclude 'mf_data_dev.*' --drop /tmp/home/dev/dumps_`date +%Y`_`date +%m%d`/MongoDB
echo " ------------ Восстановлена БД Mongo"
echo " ------------ END"
